sap.ui.define([
	"brcomfortlevcadmaterial/cadmaterial/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
