/* global QUnit */

sap.ui.require(["br/com/fortlev/cadmaterial/cadmaterial/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
